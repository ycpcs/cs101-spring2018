#include<stdio.h>
#include<math.h>

// TODO: Insert you code here
