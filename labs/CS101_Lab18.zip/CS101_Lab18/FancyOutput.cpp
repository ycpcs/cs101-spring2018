#include "Console.h"

int main(void)
{
	cons_clear_screen();
	
	// Don't change anything above this line

	// TODO: Add your code here

	// Don't change anything below this line
	
	cons_update();
	cons_wait_for_keypress();
	
	return 0;
}
